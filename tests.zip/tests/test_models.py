import unittest
from datetime import datetime
from models import Customer, Product, DiscountedProduct, Order, OrderItem, ValidationError, quicksort_orders


class TestModels(unittest.TestCase):
    def test_customer_validation(self):
        # Валидные
        c = Customer(name="Иван", email="ivan@example.com", phone="+7 999 123-45-67", city="Москва")
        self.assertEqual(c.city, "Москва")
        # Невалидный email
        with self.assertRaises(ValidationError):
            Customer(name="X", email="bad", phone="+7 999 123-45-67", city="X")
        # Невалидный телефон
        with self.assertRaises(ValidationError):
            Customer(name="X", email="x@x.com", phone="bad", city="X")

    def test_discounted_product(self):
        p = DiscountedProduct(name="Товар", price=100.0, sku="SKU1", discount_pct=10)
        self.assertAlmostEqual(p.final_price, 90.0)

    def test_order_total_and_quicksort(self):
        o1 = Order(customer_id=1, created_at=datetime(2024, 1, 1))
        o1.add_item(OrderItem(product_id=1, quantity=2, unit_price=10.0))
        o2 = Order(customer_id=1, created_at=datetime(2024, 1, 2))
        o2.add_item(OrderItem(product_id=1, quantity=1, unit_price=50.0))
        self.assertEqual(o1.total(), 20.0)
        self.assertEqual(o2.total(), 50.0)
        sorted_by_total = quicksort_orders([o2, o1], key=lambda o: o.total())
        self.assertEqual(sorted_by_total[0].total(), 20.0)


if __name__ == "__main__":
    unittest.main()
