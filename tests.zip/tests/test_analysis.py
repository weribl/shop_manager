import unittest
import os
from datetime import datetime
import db
from models import Customer, Product, Order, OrderItem
import analysis


class TestAnalysis(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        # Чистая БД
        if os.path.exists(db.DB_PATH):
            os.remove(db.DB_PATH)
        db.init_db()
        # Данные
        cid = db.add_customer(Customer(name="A", email="a@a.com", phone="+1 111 111", city="X"))
        pid = db.add_product(Product(name="P", price=10.0, sku="SKU1"))
        o = Order(customer_id=cid, created_at=datetime(2024, 1, 1))
        o.add_item(OrderItem(product_id=pid, quantity=2, unit_price=10.0))
        db.add_order(o)

    def test_df_orders(self):
        df = analysis.df_orders()
        self.assertGreaterEqual(len(df), 1)
        self.assertIn("total", df.columns)

    def test_graph_build(self):
        G = analysis.customer_graph(show=False)
        self.assertGreaterEqual(len(G.nodes), 1)


if __name__ == "__main__":
    unittest.main()
